             /* Binary search of a given element in a given ordered array
   returning 1 if the element is present and 0 if not.

   This example is like Bsearch but contains an error at line 21
   which causes several cases to have a "failure" verdict.
   
   For most of the failed test cases,
   this implementation returns 1 even though the element is not present in the array,
   which gives an indication of the location of the error. */

int Bsearch( int A[10], int elem)
{
  int low, high, mid, found ;

  low = 0 ;
  high = 9 ;
  found = 0 ;
  while( ( high > low ) )                     /* line 18 */
    { 
      mid = (low + high) / 2 ; /* error, next line should be : if( elem == A[mid] ) */
      if( elem != A[mid] )                    /* line 21 */ 
	found = 1;
      if( elem > A[mid] )                     /* line 23 */
        low = mid + 1 ;
      else
        high = mid - 1;
    }  
  mid = (low + high) / 2 ;

  if( ( found != 1)  && ( elem == A[mid]) )   /* line 30 */
    found = 1; 

  return found ;
}
