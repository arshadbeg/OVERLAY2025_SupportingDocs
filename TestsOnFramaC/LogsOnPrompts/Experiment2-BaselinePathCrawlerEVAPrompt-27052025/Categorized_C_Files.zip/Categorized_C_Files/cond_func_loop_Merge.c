           /* Merge of two given ordered arrays t1 and t2 of length l1 and l2 resp.
   into a ordered array t3

   This example is interesting because
   - there are many infeasible paths
   - it inputs arrays of variable length
   - the k-path criterion is used to limit the number of paths
   - it needs a precondition : t1 and t2 must be ordered and
     l1 resp. l2 must be no greater than the dimension of t1 resp. t2 and
     the dimension of t3 must be no smaller than the sum of the dimensions of t1 and t2
   - the oracle can also be quite complicated: t1 and t2 should not be modified
     t3 should contain just the elements of t1 and t2,
     with the same number of occurrences and in order */

void Merge (int t1[], int t2[], int t3[], int l1, int l2) {

  int i = 0;
  int j = 0;
  int k = 0;

  while (i < l1 && j < l2) {     /* line 21 */
    if (t1[i] < t2[j]) {     /* line 22 */
      t3[k] = t1[i];
      i++;
      }
    else {
      t3[k] = t2[j];
      j++;
      }
    k++;
    }
  while (i < l1) {     /* line 32 */
    t3[k] = t1[i];
    i++;
    k++;
    }
  while (j < l2) {     /* line 37 */
    t3[k] = t2[j];
    j++;
    k++;
    }
}
