             int x, y;
int f ( int a ) {
  int sum;  
  if(a == 0){  // line 04
    x = 0; y = 0;
  }else{
    x = 5; y = 5;
  } 
  sum = x + y; // sum can be 0
  pathcrawler_assert( sum != 0 );
  return 10 / sum; // risk of division by 0
}
