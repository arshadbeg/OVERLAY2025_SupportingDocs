          /* A little example from test generation literature
   containing arrays with fixed dimensions and loops with fixed limits
   but the oracle is more complicated than the implementation !
   
   Returns 0 if at least one element of array a
                and all elements of array b
                are equal to target
   and 1 otherwise */

int sample(int a[4], int b[4], int target)
{
  int i, fa, fb;

  i=0;
  fa=0;  /* found at least one occurrence of target in array a */
  fb=0;  /* found at least one occurrence of target in array a
            and all elements of array b are equal to target */

  while(i<=3){                    /* line 19 */
    if(a[i]==target) fa=1;        /* line 20 */
    ++i;
  }
  if(fa==1){                      /* line 23 */
    i=0;
    fb=1;
    while(i<=3){                  /* line 26 */
      if(b[i]!=target) fb=0;      /* line 27 */
      ++i;
    }
  }
  if(fb==1) return 0;             /* line 31 */
  else return 1;
  
}
