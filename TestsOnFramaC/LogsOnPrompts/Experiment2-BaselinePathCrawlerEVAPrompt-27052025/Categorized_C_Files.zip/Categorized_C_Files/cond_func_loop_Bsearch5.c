           /* Binary search of a given element in a given ordered array
   returning 1 if the element is present and 0 if not.

   In this example, the array dimension is fixed.
   The example is interesting because of
   - the loop with a varaible number of iterations
   - the precondition that the input array is ordered and
   - an example of an oracle which is a more inefficient implementation
     of the same algorithm. */

int Bsearch( int A[10], int elem)
{
  int low, high, mid, found ;

  low = 0 ;
  high = 9 ;
  found = 0 ;
  while( ( high > low ) )                     /* line 18 */
    { 
      mid = (low + high) / 2 ;
      if( elem == A[mid] )                    /* line 21 */
	found = 1;
      if( elem > A[mid] )                     /* line 23 */
        low = mid + 1 ;
      else
        high = mid - 1;
    }  
  mid = (low + high) / 2 ;

  if( ( found != 1)  && ( elem == A[mid]) )   /* line 30 */
    found = 1; 

  return found ;
}
