/* Merge of two given ordered arrays 
   t1 and t2 of length l1 and l2 resp.
   into a ordered array t3


   This example is like Merge
   but gives an example of a precondition 
   coded in C */




void Merge (int t1[], int t2[], int t3[], int l1, int l2) {

  int i = 0;
  int j = 0;
  int k = 0;

  while (i < l1 && j < l2) {     /* line 21 */
    if (t1[i] < t2[j]) {     /* line 22 */
      t3[k] = t1[i];
      i++;
      }
    else {
      t3[k] = t2[j];
      j++;
    }
    k++;
  }
  while (i < l1) {     /* line 32 */
    t3[k] = t1[i];
    i++;
    k++;
  }
  while (j < l2) {     /* line 37 */
    t3[k] = t2[j];
    j++;
    k++;
  }
}

/* C precondition of function Merge
   This must have the name of the tested function suffixed with _precond
   and have the same number of arguments with the same types.
   It must return 1 if the parameter values satisfy the precondition and 0 if not */
int Merge_precond(int t1[], int t2[], int t3[], int l1, int l2) {
  if (l1 > pathcrawler_dimension(t1)
      || l2 > pathcrawler_dimension(t2)
      || l1+l2 > pathcrawler_dimension(t3)) {
    return 0;
  }
  int i;
  for (i=1; i < l1; i++) {
    if (t1[i-1] > t1[i]) {
      return 0;
    }
  }
  for (i=1; i < l2; i++) {
    if (t2[i-1] > t2[i]) {
      return 0;
    }
  }
  return 1;
}
