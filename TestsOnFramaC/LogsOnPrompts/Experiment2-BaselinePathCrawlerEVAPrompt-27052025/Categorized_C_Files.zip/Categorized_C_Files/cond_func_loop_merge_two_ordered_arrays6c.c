            /* Should copy all the elements
   of ordered arrays t1 and t2
   of lengths l1 and l2
   into the ordered array t3 */
void Merge (int t1[], int t2[], int t3[], int l1, int l2) {

  int i = 0, j = 0, k = 0 ;

  while (i < l1 && j < l2) { // line 09
    if (t1[i] < t2[j]) {     // line 10
      t3[k] = t1[i];
      i++;
      }
    else {
      t3[k] = t2[j];
      j++;
      }
    k++;
    }
  while (i < l1) {           // line 20
    t3[k] = t1[i];
    i++;

    }
  while (j < l2) {           // line 25
    t3[k] = t2[j];
    j++;
    k++;
    }
}

