/* Merge of two given ordered arrays t1 and t2 of length l1 and l2 resp.
   into a ordered array t3

   This example is the same as Merge except that it contains an error at line 32
   which provokes a buffer overflow.
   This usually causes Merge to crash when executed on one of the test cases.
   In this case, the trace file (which can be viewed by clicking on the
   "Trace" button at the left-hand side of the Test Session Results window)
   contains a TEST EXECUTION WARNING which explains the cause of the crash.
   ( Attention: it is a cumulative trace
   for the whole user sesssion so examine the end of it) */

void Merge (int t1[], int t2[], int t3[], int l1, int l2) {

  int i = 0;
  int j = 0;
  int k = 0;

  while (i < l1 && j < l2) {     /* line 21 */
    if (t1[i] < t2[j]) {     /* line 22 */
      t3[k] = t1[i];
      i++;
      }
    else {
      t3[k] = t2[j];
      j++;
      }
    k++;
    }     /* error, next line should be : while (i < l1) */
  while (i <= l1) {     /* line 32 */
    t3[k] = t1[i];
    i++;
    k++;
    }
  while (j < l2) {     /* line 37 */
    t3[k] = t2[j];
    j++;
    k++;
    }
}
