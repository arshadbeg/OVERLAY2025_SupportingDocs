           /* Binary search of a given element in a given ordered array
   returning 1 if the element is present and 0 if not.

   This example is like Bsearch but contains an error at line 30
   which causes several cases to have a "failure" verdict.
   
   The failed test cases are exactly those which cover the paths
   in which the 1st subcondition of line 30 is satisfied,
   which indicates the location of the error. */

int Bsearch( int A[10], int elem)
{
  int low, high, mid, found ;

  low = 0 ;
  high = 9 ;
  found = 0 ;
  while( ( high > low ) )                     /* line 18 */
    { 
      mid = (low + high) / 2 ;
      if( elem == A[mid] )                    /* line 21 */ 
	found = 1;
      if( elem > A[mid] )                     /* line 23 */
        low = mid + 1 ;
      else
        high = mid - 1;
    }  
  mid = (low + high) / 2 ;
  /* error, next line should be : if( ( found != 1)  && ( elem == A[mid]) ) */
  if( ( found != 1)  && ( elem != A[mid]) )    /* line 30 */
    found = 1; 

  return found ;
}
