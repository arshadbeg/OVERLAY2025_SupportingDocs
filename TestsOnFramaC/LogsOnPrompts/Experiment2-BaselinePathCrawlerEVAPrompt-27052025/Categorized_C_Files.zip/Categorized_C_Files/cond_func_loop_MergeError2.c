/* Merge of two given ordered arrays t1 and t2 of length l1 and l2 resp.
   into a ordered array t3

   This example is the same as Merge except that it contains an error at line 35
   which means that the index of t3 is not incremented
   and the same element of t3 is overwritten.
   This causes some test-cases to give a "failure" verdict.
   By examining the outputs of these test-cases,
   the user will see that not all elements of t3 are written
   (an error that cannot be directly detected by the oracle).
   This information can be used to locate the bug. */

void Merge (int t1[], int t2[], int t3[], int l1, int l2) {

  int i = 0;
  int j = 0;
  int k = 0;

  while (i < l1 && j < l2) {     /* line 21 */
    if (t1[i] < t2[j]) {     /* line 22 */
      t3[k] = t1[i];
      i++;
      }
    else {
      t3[k] = t2[j];
      j++;
      }
    k++;
    }
  while (i < l1) {     /* line 32 */
    t3[k] = t1[i];
    i++;
/* error : missing instruction k++; here */
    }
  while (j < l2) {     /* line 37 */
    t3[k] = t2[j];
    j++;
    k++;
    }
}
