             int f(int x){ 
  if(x < 0)           // line 2
    x = x + 1; 
  if(x != 1)          // line 4
    x = 2*x; 
  return x; 
} 

int spec_f(int x){ 
  if(x < 1)           // line 10
    x = 2*(x + 1); 
  else 
    x = 2*x; 
  return x; 
} 

int cross_f(int x){
  int imp = f(x);
  int spec = spec_f(x);
  if(imp != spec)     // line 20
    return 0; 
  else return 1;
}
