             /* Bubble sort of a given array 'table' of 
   a given length 'l' in ascending order */

void bsort (int * table, int l) 
{
  int i, temp, nb;
  char done;
  done = 0;
  nb = 0;
  while ( !done && (nb < l-1)){      /* line 10 */
    done = 1;
    for (i=0 ; i<l-1 ; i++)          /* line 12 */
      if (table[i] > table[i+1]){    /* line 13 */
	done = 0;
	temp = table[i];
	table[i + 1] = temp;
      }
    nb++;
  }
}
