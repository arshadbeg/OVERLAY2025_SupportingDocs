           /* Bubble sort of a given array 'table' of 
   a given length 'l' in descending order

   This example is interesting because of its
   - variable dimension input array
   - loop with a variable number of iterations,
     which is limited by limiting the array dimension
   - oracle which does not sort but checks the result is ordered */

void bsort (int * table, int l) 
{
  int i, temp, nb;
  char fini;
  fini = 0;
  nb = 0;
  while ( !fini && (nb < l-1)){      /* line 16 */
    fini = 1;
    for (i=0 ; i<l-1 ; i++)          /* line 18 */
      if (table[i] < table[i+1]){    /* line 19 */
	fini = 0;
	temp = table[i];
	table[i] = table[i + 1];
	table[i + 1] = temp;
      }
    nb++;
  }
}
