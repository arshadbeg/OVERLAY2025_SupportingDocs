            int uninit_var(int a[3], int b[3]) {
  int i, k;
  for(i=0; i<2; i++) {     // line 3
      if(a[i] == 0)        // line 4
	return 0;
      if(a[i] != a[i+1])   // line 6
        k = 0;
      else
        if(k == 2)         // line 9
	  return 0;
      while(b[k] != a[i])  // line 11
          if(k == 2)       // line 12
	    return 0;
          else
            k++;
      }
  return 1;
}
